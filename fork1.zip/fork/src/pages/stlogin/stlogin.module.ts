import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StloginPage } from './stlogin';

@NgModule({
  declarations: [
    StloginPage,
  ],
  imports: [
    IonicPageModule.forChild(StloginPage),
  ],
})
export class StloginPageModule {}
