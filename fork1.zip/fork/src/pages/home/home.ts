import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LogPage } from '../log/log';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
 button:any;
  constructor(public navCtrl: NavController) {
this.button= LogPage;
  }

}
